import type { DatosEvaluacion } from "../procesar-evaluacion-background.js";
import type { Scores, Interpretacion } from "./calcularScores.js";
import { estadoPorScore, coloresPorEstado } from "./calcularScores.js";

// ─── Envío principal ──────────────────────────────────────────
export async function enviarEmailBienvenida(
  datos: DatosEvaluacion,
  scores: Scores,
  interp: Interpretacion,
  pdfBuffer: Buffer
): Promise<void> {
  const apiKey = Netlify.env.get("RESEND_API_KEY");
  if (!apiKey) throw new Error("RESEND_API_KEY no configurada");

  const remitente = Netlify.env.get("EMAIL_FROM") ?? "CAIH <noreply@caihoficial.com>";

  const html = buildEmailHTML(datos, scores, interp);
  const pdfBase64 = pdfBuffer.toString("base64");

  const payload = {
    from: remitente,
    to: [datos.email],
    subject: `Tu Reporte Biosistémico está listo, ${datos.nombre} — CAIH`,
    html,
    attachments: [
      {
        filename: `CAIH_${datos.nombre.replace(/\s+/g, "_")}_Reporte_Biosistemico.pdf`,
        content: pdfBase64,
      },
    ],
  };

  const res = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(payload),
  });

  if (!res.ok) {
    const err = await res.text();
    throw new Error(`Resend error ${res.status}: ${err}`);
  }
}

// ─── Plantilla HTML del email ─────────────────────────────────
function buildEmailHTML(
  datos: DatosEvaluacion,
  scores: Scores,
  interp: Interpretacion
): string {
  const scoreItems = [
    { label: "Capa 1<br>Entorno",     score: scores.capa1 },
    { label: "Capa 2<br>Regulación",  score: scores.capa2 },
    { label: "Capa 3<br>Metabolismo", score: scores.capa3 },
    { label: "Capa 4<br>Fenotipo",    score: scores.capa4 },
    { label: "Índice<br>Global",      score: scores.indiceGlobal, bold: true },
  ];

  const scoreCells = scoreItems.map(({ label, score, bold }) => {
    const estado = estadoPorScore(score);
    const { color, colorLight } = coloresPorEstado(score);
    return `
      <td width="20%" align="center" style="padding:0 3px;">
        <div style="background:${colorLight};border:${bold ? "2" : "1.5"}px solid ${color};border-radius:8px;padding:10px 4px;text-align:center;">
          <div style="font-size:20px;font-weight:700;color:${color};font-family:Arial,sans-serif;">${score}</div>
          <div style="font-size:9px;font-weight:700;color:#085041;margin:3px 0;font-family:Arial,sans-serif;line-height:1.3;">${label}</div>
          <div style="font-size:8px;font-weight:700;color:${color};font-family:Arial,sans-serif;">${estado}</div>
        </div>
      </td>`;
  }).join("");

  // Acciones inmediatas (primeras 4 del protocolo)
  const accionesHTML = interp.protocolo.slice(0, 4).map((item, i) => `
    <tr><td style="padding:5px 0;font-size:13px;color:#085041;font-family:Arial,sans-serif;border-bottom:1px solid #9FE1CB;">
      <strong>${String(i + 1).padStart(2, "0")} · ${item.tipo}</strong> — ${item.accion.split(".")[0]}.
    </td></tr>`).join("");

  return `<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body style="margin:0;padding:0;background:#f5f4f0;font-family:Arial,sans-serif;">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#f5f4f0;padding:32px 0;">
<tr><td align="center">
<table width="580" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:12px;overflow:hidden;max-width:580px;">

  <!-- Header -->
  <tr><td style="background:#0F6E56;padding:28px 36px 24px;">
    <table width="100%" cellpadding="0" cellspacing="0"><tr>
      <td>
        <div style="font-size:26px;font-weight:700;color:#ffffff;letter-spacing:-0.5px;">CAIH</div>
        <div style="font-size:11px;color:#9FE1CB;margin-top:2px;">Centro de Alta Integración Humana</div>
      </td>
      <td align="right">
        <div style="font-size:11px;color:#9FE1CB;">Salvador Roka</div>
        <div style="font-size:10px;color:#5DCAA5;margin-top:2px;">Etiólogo · Especialista en Optimización Celular</div>
      </td>
    </tr></table>
  </td></tr>

  <!-- Saludo -->
  <tr><td style="padding:32px 36px 16px;">
    <p style="font-size:18px;font-weight:700;color:#085041;margin:0 0 14px;">Hola, ${datos.nombre}.</p>
    <p style="font-size:14px;color:#2C2C2A;line-height:1.75;margin:0 0 12px;">
      Tu sistema ha hablado. Y tiene sentido.
    </p>
    <p style="font-size:14px;color:#2C2C2A;line-height:1.75;margin:0;">
      He revisado tu evaluación y te envío tu <strong>Reporte de Interpretación Biosistémica</strong> — 
      un análisis completo de las 5 capas de tu sistema operativo biológico, con el punto exacto 
      donde perdiste la autorregulación y el protocolo diseñado específicamente para ti.
    </p>
  </td></tr>

  <!-- Resumen -->
  <tr><td style="padding:0 36px 20px;">
    <div style="background:#F1EFE8;border-radius:8px;padding:18px 22px;">
      <div style="font-size:11px;font-weight:700;color:#0F6E56;text-transform:uppercase;letter-spacing:.06em;margin-bottom:12px;">Resumen de tu evaluación</div>
      <table width="100%" cellpadding="0" cellspacing="0">
        <tr>
          <td style="padding:5px 0;font-size:12px;color:#5F5E5A;border-bottom:1px solid #D3D1C7;">Motivo de consulta</td>
          <td align="right" style="padding:5px 0;font-size:12px;font-weight:700;color:#2C2C2A;border-bottom:1px solid #D3D1C7;">${datos.motivo}</td>
        </tr>
        <tr>
          <td style="padding:5px 0;font-size:12px;color:#5F5E5A;border-bottom:1px solid #D3D1C7;">Punto de pérdida detectado</td>
          <td align="right" style="padding:5px 0;font-size:12px;font-weight:700;color:#D85A30;border-bottom:1px solid #D3D1C7;">Capa ${interp.capaFallo} — ${interp.nombreCapaFallo}</td>
        </tr>
        <tr>
          <td style="padding:5px 0;font-size:12px;color:#5F5E5A;border-bottom:1px solid #D3D1C7;">Índice global del sistema</td>
          <td align="right" style="padding:5px 0;font-size:12px;font-weight:700;color:#D85A30;border-bottom:1px solid #D3D1C7;">${scores.indiceGlobal} / 100</td>
        </tr>
        <tr>
          <td style="padding:5px 0;font-size:12px;color:#5F5E5A;">Tipo de atractor</td>
          <td align="right" style="padding:5px 0;font-size:12px;font-weight:700;color:#2C2C2A;">${interp.tipoAttractor}</td>
        </tr>
      </table>
    </div>
  </td></tr>

  <!-- Scores -->
  <tr><td style="padding:0 36px 20px;">
    <div style="font-size:11px;font-weight:700;color:#0F6E56;text-transform:uppercase;letter-spacing:.06em;margin-bottom:10px;">Scores por capa</div>
    <table width="100%" cellpadding="0" cellspacing="0"><tr>${scoreCells}</tr></table>
  </td></tr>

  <!-- Síntesis -->
  <tr><td style="padding:0 36px 20px;">
    <div style="border-left:3px solid #0F6E56;padding-left:16px;">
      <p style="font-size:13px;color:#2C2C2A;line-height:1.75;margin:0;">
        ${interp.resumenEjecutivo}
      </p>
    </div>
  </td></tr>

  <!-- Acciones inmediatas -->
  <tr><td style="padding:0 36px 24px;">
    <div style="background:#E1F5EE;border-radius:8px;padding:18px 22px;">
      <div style="font-size:11px;font-weight:700;color:#0F6E56;text-transform:uppercase;letter-spacing:.06em;margin-bottom:12px;">Puedes empezar hoy</div>
      <table width="100%" cellpadding="0" cellspacing="0">${accionesHTML}</table>
    </div>
  </td></tr>

  <!-- CTA -->
  <tr><td style="padding:0 36px 32px;">
    <p style="font-size:14px;color:#2C2C2A;line-height:1.75;margin:0 0 16px;">
      El reporte completo con el análisis capa por capa, el diagnóstico integrado y el protocolo personalizado 
      está <strong>adjunto a este correo en PDF</strong>.
    </p>
    <p style="font-size:14px;color:#2C2C2A;line-height:1.75;margin:0 0 20px;">
      El siguiente paso natural es el <strong>Programa de Reconfiguración Sistémica (P02)</strong>: 
      2 meses, 3 sesiones, protocolo ajustado dinámicamente a tu sistema. 
      Precio cerrado: <strong>247 €</strong>.
    </p>
    <table cellpadding="0" cellspacing="0"><tr>
      <td style="background:#0F6E56;border-radius:8px;padding:13px 28px;">
        <a href="https://wa.me/message/caih" style="color:#ffffff;font-size:14px;font-weight:700;text-decoration:none;">
          Reservar sesión por WhatsApp →
        </a>
      </td>
      <td style="padding-left:14px;">
        <a href="mailto:caihoficial@gmail.com" style="color:#0F6E56;font-size:13px;font-weight:700;text-decoration:none;">
          o escríbeme por email
        </a>
      </td>
    </tr></table>
  </td></tr>

  <!-- Firma -->
  <tr><td style="background:#F1EFE8;padding:20px 36px;border-top:1px solid #D3D1C7;">
    <table width="100%" cellpadding="0" cellspacing="0"><tr>
      <td>
        <div style="font-size:13px;font-weight:700;color:#085041;">Salvador Roka</div>
        <div style="font-size:11px;color:#5F5E5A;margin-top:2px;">Etiólogo · Especialista en Optimización Celular · Fundador CAIH</div>
        <div style="font-size:11px;color:#5F5E5A;margin-top:4px;">caihoficial@gmail.com · @caih.oficial</div>
      </td>
      <td align="right">
        <div style="font-size:22px;font-weight:700;color:#0F6E56;">CAIH</div>
      </td>
    </tr></table>
  </td></tr>

  <!-- Legal -->
  <tr><td style="padding:14px 36px;background:#f5f4f0;">
    <p style="font-size:10px;color:#888780;line-height:1.5;margin:0;text-align:center;">
      Este correo contiene información educativa e informativa. No constituye diagnóstico médico 
      ni sustituye la consulta con un profesional de la salud habilitado. 
      CAIH · caihoficial@gmail.com · @caih.oficial
    </p>
  </td></tr>

</table>
</td></tr>
</table>
</body>
</html>`;
}

// ─── Helper colores (reexportado para el email) ───────────────
function coloresPorEstado(score: number) {
  if (score < 30) return { color: "#D85A30", colorLight: "#FAECE7" };
  if (score < 55) return { color: "#BA7517", colorLight: "#FAEEDA" };
  return { color: "#1D9E75", colorLight: "#E1F5EE" };
}
