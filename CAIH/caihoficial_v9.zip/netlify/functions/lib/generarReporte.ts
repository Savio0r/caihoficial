import PDFDocument from "pdfkit";
import type { DatosEvaluacion } from "../procesar-evaluacion-background.js";
import type { Scores, Interpretacion } from "./calcularScores.js";
import { estadoPorScore, coloresPorEstado } from "./calcularScores.js";

// ─── Paleta CAIH ─────────────────────────────────────────────
const C = {
  teal:      "#0F6E56",
  tealMid:   "#1D9E75",
  tealLight: "#E1F5EE",
  tealDark:  "#085041",
  dark:      "#2C2C2A",
  gray:      "#5F5E5A",
  grayLight: "#F1EFE8",
  grayMid:   "#D3D1C7",
  coral:     "#D85A30",
  coralLight:"#FAECE7",
  amber:     "#BA7517",
  amberLight:"#FAEEDA",
  white:     "#FFFFFF",
} as const;

// ─── Constantes de layout ─────────────────────────────────────
const PW  = 595.28;   // A4 width  en pt
const PH  = 841.89;   // A4 height en pt
const ML  = 50;       // margen izquierdo
const MR  = 50;       // margen derecho
const CW  = PW - ML - MR;  // ancho de contenido
const TOP = 120;      // inicio de contenido tras header

// ─── Generador principal ──────────────────────────────────────
export async function generarReportePDF(
  datos: DatosEvaluacion,
  scores: Scores,
  interp: Interpretacion
): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    const chunks: Buffer[] = [];
    const doc = new PDFDocument({ size: "A4", margin: 0, bufferPages: true });

    doc.on("data", (chunk: Buffer) => chunks.push(chunk));
    doc.on("end", () => resolve(Buffer.concat(chunks)));
    doc.on("error", reject);

    // ── Páginas ──────────────────────────────────────────────
    renderPortada(doc, datos, scores, interp);
    doc.addPage();
    renderAnalisis(doc, datos, scores, interp);
    doc.addPage();
    renderProtocolo(doc, interp);

    // ── Footer en todas las páginas ──────────────────────────
    const range = doc.bufferedPageRange();
    for (let i = 0; i < range.count; i++) {
      doc.switchToPage(range.start + i);
      renderHeader(doc, datos.nombre);
      renderFooter(doc, i + 1, range.count);
    }

    doc.end();
  });
}

// ─── Header y footer ─────────────────────────────────────────
function renderHeader(doc: PDFKit.PDFDocument, nombre: string) {
  // Franja teal superior
  doc.rect(0, 0, PW, 85).fill(C.teal);

  // Logo CAIH
  doc.font("Helvetica-Bold").fontSize(20).fillColor(C.white)
     .text("CAIH", ML, 22, { lineBreak: false });

  doc.font("Helvetica").fontSize(8).fillColor(C.tealLight)
     .text("Centro de Alta Integración Humana", ML, 44);

  // Título derecha
  doc.font("Helvetica-Bold").fontSize(11).fillColor(C.white)
     .text("Reporte de Interpretación Biosistémica", 0, 24, { align: "right", width: PW - MR });

  doc.font("Helvetica").fontSize(8).fillColor(C.tealLight)
     .text(`Informe personalizado · ${nombre}`, 0, 40, { align: "right", width: PW - MR });

  // Línea separadora
  doc.moveTo(0, 86).lineTo(PW, 86).strokeColor(C.tealMid).lineWidth(0.5).stroke();
}

function renderFooter(doc: PDFKit.PDFDocument, page: number, total: number) {
  const y = PH - 36;
  doc.rect(0, y, PW, 36).fill(C.grayLight);
  doc.moveTo(0, y).lineTo(PW, y).strokeColor(C.grayMid).lineWidth(0.3).stroke();

  doc.font("Helvetica").fontSize(7).fillColor(C.gray)
     .text("CAIH · Salvador Roka · Etiólogo y Especialista en Optimización Celular", ML, y + 8);
  doc.text("caihoficial@gmail.com  ·  @caih.oficial", ML, y + 18);
  doc.text(`Pág. ${page} / ${total}`, 0, y + 13, { align: "right", width: PW - MR });
}

// ─── Página 1 — Portada + dashboard ──────────────────────────
function renderPortada(
  doc: PDFKit.PDFDocument,
  datos: DatosEvaluacion,
  scores: Scores,
  interp: Interpretacion
) {
  let y = TOP;

  // ── Datos del informe ────────────────────────────────────
  y = seccionBox(doc, y, "Datos del informe");
  y += 6;

  const datosFilas = [
    ["Cliente",           datos.nombre,                "N.º reporte",  "CAIH-RIB-2026"],
    ["Email",             datos.email,                 "Fecha",        new Date().toLocaleDateString("es-ES", { year: "numeric", month: "long", day: "numeric" })],
    ["Motivo",            datos.motivo,                "Evaluador",    "Salvador Roka"],
    ["Capa de pérdida",   `Capa ${interp.capaFallo} — ${interp.nombreCapaFallo}`,
     "Índice global",     `${scores.indiceGlobal}/100`],
  ];

  for (const [k1, v1, k2, v2] of datosFilas) {
    const isLastRow = k1 === "Capa de pérdida";
    const colV1 = isLastRow ? C.coral : C.dark;
    const colV2 = isLastRow ? C.coral : C.dark;

    doc.rect(ML, y, CW / 2 - 2, 18).fill(C.grayLight);
    doc.rect(ML + CW / 2 + 2, y, CW / 2 - 2, 18).fill(C.grayLight);
    doc.rect(ML + CW / 4, y, CW / 4, 18).fill(C.white);
    doc.rect(ML + CW * 3 / 4, y, CW / 4, 18).fill(C.white);

    doc.font("Helvetica-Bold").fontSize(7.5).fillColor(C.tealDark)
       .text(k1, ML + 5, y + 5, { width: CW / 4 - 10 });
    doc.font("Helvetica").fontSize(8.5).fillColor(colV1)
       .text(v1, ML + CW / 4 + 5, y + 4, { width: CW / 4 - 10 });
    doc.font("Helvetica-Bold").fontSize(7.5).fillColor(C.tealDark)
       .text(k2, ML + CW / 2 + 7, y + 5, { width: CW / 4 - 10 });
    doc.font("Helvetica").fontSize(8.5).fillColor(colV2)
       .text(v2, ML + CW * 3 / 4 + 5, y + 4, { width: CW / 4 - 10 });

    doc.rect(ML, y, CW / 2 - 2, 18).strokeColor(C.grayMid).lineWidth(0.3).stroke();
    doc.rect(ML + CW / 2 + 2, y, CW / 2 - 2, 18).strokeColor(C.grayMid).lineWidth(0.3).stroke();
    y += 19;
  }
  y += 10;

  // ── Síntesis ─────────────────────────────────────────────
  y = seccionBox(doc, y, "Síntesis del sistema");
  y += 8;

  doc.font("Helvetica").fontSize(9.5).fillColor(C.dark)
     .text(interp.resumenEjecutivo, ML, y, { width: CW, align: "justify" });
  y += doc.heightOfString(interp.resumenEjecutivo, { width: CW }) + 10;

  // Cita
  doc.rect(ML, y, 3, 32).fill(C.teal);
  doc.font("Helvetica-Oblique").fontSize(9).fillColor(C.tealDark)
     .text(
       '"El cuerpo no enferma por azar ni por debilidad. Enferma porque el entorno en el que opera ha dejado de sostenerle."',
       ML + 12, y + 4, { width: CW - 12 }
     );
  y += 42;
  doc.font("Helvetica").fontSize(7.5).fillColor(C.gray)
     .text("— Salvador Roka, Fundador CAIH", ML + 12, y);
  y += 18;

  // ── Dashboard de scores ───────────────────────────────────
  y = seccionBox(doc, y, "Dashboard biosistémico — Scores por capa");
  y += 10;

  const scoreItems = [
    { label: "Capa 1\nEntorno",     score: scores.capa1 },
    { label: "Capa 2\nRegulación",  score: scores.capa2 },
    { label: "Capa 3\nMetabolismo", score: scores.capa3 },
    { label: "Capa 4\nFenotipo",    score: scores.capa4 },
    { label: "Índice\nGlobal",      score: scores.indiceGlobal },
  ];

  const cellW = CW / 5 - 4;
  let cx = ML;

  for (const { label, score } of scoreItems) {
    const estado = estadoPorScore(score);
    const { color, colorLight } = coloresPorEstado(estado);

    doc.rect(cx, y, cellW, 64).fill(colorLight);
    doc.rect(cx, y, cellW, 64).strokeColor(color).lineWidth(1).stroke();

    doc.font("Helvetica-Bold").fontSize(22).fillColor(color)
       .text(String(score), cx, y + 8, { width: cellW, align: "center" });

    doc.font("Helvetica-Bold").fontSize(7.5).fillColor(C.tealDark)
       .text(label, cx, y + 36, { width: cellW, align: "center" });

    doc.font("Helvetica-Bold").fontSize(7).fillColor(color)
       .text(estado, cx, y + 53, { width: cellW, align: "center" });

    cx += cellW + 5;
  }
  y += 74;

  // ── Diagnóstico integrado ─────────────────────────────────
  y += 4;
  y = seccionBox(doc, y, "Diagnóstico biosistémico integrado");
  y += 6;

  const diagFilas = [
    ["Punto de pérdida",    `Capa ${interp.capaFallo} — ${interp.nombreCapaFallo}`, true],
    ["Tipo de atractor",    interp.tipoAttractor, false],
    ["Cascada detectada",   interp.cascada, false],
    ["Variables críticas",  "pH · voltaje · tono simpático · ATP celular", false],
    ["Índice global",       `${scores.indiceGlobal}/100 — Sistema en modo supervivencia metabólica`, true],
  ];

  for (const [k, v, esAlerta] of diagFilas) {
    const rowH = 18;
    doc.rect(ML, y, 110, rowH).fill(C.grayLight);
    doc.rect(ML + 110, y, CW - 110, rowH).fill(C.white);
    doc.rect(ML, y, CW, rowH).strokeColor(C.grayMid).lineWidth(0.3).stroke();

    doc.font("Helvetica-Bold").fontSize(7.5).fillColor(C.tealDark)
       .text(k as string, ML + 5, y + 5, { width: 100 });
    doc.font(esAlerta ? "Helvetica-Bold" : "Helvetica")
       .fontSize(8.5)
       .fillColor(esAlerta ? C.coral : C.dark)
       .text(v as string, ML + 115, y + 4, { width: CW - 120 });
    y += rowH;
  }
}

// ─── Página 2 — Análisis por capa ────────────────────────────
function renderAnalisis(
  doc: PDFKit.PDFDocument,
  datos: DatosEvaluacion,
  scores: Scores,
  interp: Interpretacion
) {
  let y = TOP;
  y = seccionBox(doc, y, "Análisis detallado por capa");
  y += 8;

  const capaScores = [scores.capa1, scores.capa2, scores.capa3, scores.capa4];

  for (let i = 1; i <= 4; i++) {
    const capa = interp.capas[i];
    const score = capaScores[i - 1];
    const { color, colorLight } = coloresPorEstado(capa.estado);

    // Header de capa
    const hdH = 24;
    doc.rect(ML, y, CW, hdH).fill(colorLight);
    doc.rect(ML, y, CW, hdH).strokeColor(color).lineWidth(0.5).stroke();

    doc.font("Helvetica-Bold").fontSize(10).fillColor(C.tealDark)
       .text(`Capa ${i} — ${capa.titulo}`, ML + 8, y + 7, { width: 160 });

    doc.font("Helvetica").fontSize(7.5).fillColor(C.gray)
       .text(capa.variables, ML + 172, y + 8, { width: 220 });

    doc.font("Helvetica-Bold").fontSize(10).fillColor(color)
       .text(`${score}/100`, PW - MR - 80, y + 7, { width: 40, align: "right" });

    doc.font("Helvetica-Bold").fontSize(8).fillColor(color)
       .text(capa.estado, PW - MR - 55, y + 8, { width: 55, align: "right" });

    y += hdH + 4;

    // Análisis
    const analH = doc.heightOfString(capa.analisis, { width: CW - 10 }) + 8;
    doc.rect(ML, y, CW, analH).fill(C.white);
    doc.font("Helvetica").fontSize(9).fillColor(C.dark)
       .text(capa.analisis, ML + 8, y + 5, { width: CW - 16, align: "justify" });
    y += analH + 8;

    // Comprueba si hay espacio suficiente
    if (y > PH - 100) break;
  }
}

// ─── Página 3 — Protocolo y pasos ────────────────────────────
function renderProtocolo(
  doc: PDFKit.PDFDocument,
  interp: Interpretacion
) {
  let y = TOP;

  // ── Protocolo ────────────────────────────────────────────
  y = seccionBox(doc, y, "Protocolo de intervención recomendado");
  y += 6;

  doc.font("Helvetica").fontSize(9).fillColor(C.dark)
     .text(
       "La intervención comienza en la capa de pérdida, no en el síntoma. " +
       "Cuando el entorno cambia, el metabolismo responde.",
       ML, y, { width: CW }
     );
  y += 20;

  // Cabecera tabla
  const colWidths = [60, CW - 60 - 70, 70];
  const rowH = 18;

  doc.rect(ML, y, CW, rowH).fill(C.teal);
  doc.font("Helvetica-Bold").fontSize(8).fillColor(C.white)
     .text("Tipo", ML + 5, y + 5, { width: colWidths[0] });
  doc.text("Acción recomendada", ML + colWidths[0] + 5, y + 5, { width: colWidths[1] });
  doc.text("Frecuencia", ML + colWidths[0] + colWidths[1] + 5, y + 5, { width: colWidths[2] });
  y += rowH;

  for (let idx = 0; idx < interp.protocolo.length; idx++) {
    const item = interp.protocolo[idx];
    const bg = idx % 2 === 0 ? C.white : C.grayLight;
    const textH = Math.max(
      doc.heightOfString(item.accion, { width: colWidths[1] - 10 }) + 10,
      28
    );

    doc.rect(ML, y, CW, textH).fill(bg);
    doc.rect(ML, y, CW, textH).strokeColor(C.grayMid).lineWidth(0.3).stroke();

    doc.font("Helvetica-Bold").fontSize(8).fillColor(C.tealDark)
       .text(item.tipo, ML + 5, y + 5, { width: colWidths[0] - 10 });

    doc.font("Helvetica").fontSize(8).fillColor(C.dark)
       .text(item.accion, ML + colWidths[0] + 5, y + 5, { width: colWidths[1] - 10 });

    doc.font("Helvetica").fontSize(8).fillColor(C.gray)
       .text(item.frecuencia, ML + colWidths[0] + colWidths[1] + 5, y + 5, { width: colWidths[2] - 10 });

    y += textH;
  }
  y += 14;

  // ── Próximos pasos ────────────────────────────────────────
  y = seccionBox(doc, y, "Próximos pasos");
  y += 8;

  for (const paso of interp.proximosPasos) {
    const descH = doc.heightOfString(paso.descripcion, { width: CW - 46 }) + 8;
    const boxH = Math.max(44, descH + 22);

    doc.rect(ML, y, 34, boxH).fill(C.teal);
    doc.font("Helvetica-Bold").fontSize(15).fillColor(C.tealLight)
       .text(paso.numero, ML, y + (boxH - 18) / 2, { width: 34, align: "center" });

    doc.rect(ML + 34, y, CW - 34, boxH).fill(C.grayLight);
    doc.font("Helvetica-Bold").fontSize(9.5).fillColor(C.teal)
       .text(paso.titulo, ML + 42, y + 7, { width: CW - 50 });
    doc.font("Helvetica").fontSize(8.5).fillColor(C.dark)
       .text(paso.descripcion, ML + 42, y + 22, { width: CW - 50 });

    doc.rect(ML, y, CW, boxH).strokeColor(C.grayMid).lineWidth(0.3).stroke();
    y += boxH + 5;
  }
  y += 10;

  // ── Aviso legal ───────────────────────────────────────────
  doc.moveTo(ML, y).lineTo(ML + CW, y).strokeColor(C.grayMid).lineWidth(0.3).stroke();
  y += 8;
  doc.font("Helvetica").fontSize(7.5).fillColor(C.gray)
     .text(
       "Este reporte tiene carácter educativo e informativo. No constituye diagnóstico médico " +
       "ni sustituye la consulta con un profesional de la salud habilitado. " +
       "Propiedad intelectual exclusiva de Salvador Roka y CAIH.",
       ML, y, { width: CW, align: "center" }
     );
}

// ─── Utilidad: caja de sección ────────────────────────────────
function seccionBox(doc: PDFKit.PDFDocument, y: number, texto: string): number {
  const h = 22;
  doc.rect(ML, y, CW, h).fill(C.teal);
  doc.font("Helvetica-Bold").fontSize(9.5).fillColor(C.white)
     .text(texto, ML + 8, y + 6, { width: CW - 16 });
  return y + h;
}
