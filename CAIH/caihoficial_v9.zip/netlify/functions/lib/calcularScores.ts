import type { DatosEvaluacion } from "../procesar-evaluacion-background.js";

// ─── Tipos de scores ─────────────────────────────────────────
export interface Scores {
  capa1: number;
  capa2: number;
  capa3: number;
  capa4: number;
  indiceGlobal: number;
}

export type EstadoCapa = "ÓPTIMO" | "ALERTA" | "CRÍTICO";

export interface InterpretacionCapa {
  estado: EstadoCapa;
  color: string;        // hex para PDF/email
  colorLight: string;
  titulo: string;
  variables: string;
  analisis: string;
  accionClave: string;
}

export interface Interpretacion {
  capas: Record<number, InterpretacionCapa>;
  capaFallo: number;
  nombreCapaFallo: string;
  tipoAttractor: string;
  cascada: string;
  resumenEjecutivo: string;
  protocolo: ProtocoloItem[];
  proximosPasos: PasoItem[];
}

export interface ProtocoloItem {
  tipo: string;
  accion: string;
  frecuencia: string;
}

export interface PasoItem {
  numero: string;
  titulo: string;
  descripcion: string;
}

// ─── Cálculo de scores ────────────────────────────────────────
export function calcularScores(datos: DatosEvaluacion): Scores {
  const n = (v: string) => Math.min(100, Math.max(0, parseInt(v ?? "0", 10)));

  const capa1 = Math.round((n(datos["capa1-ph"]) + n(datos["capa1-emocion"])) / 2);
  const capa2 = Math.round((n(datos["capa2-sna"]) + n(datos["capa2-cortisol"])) / 2);
  const capa3 = Math.round((n(datos["capa3-atp"]) + n(datos["capa3-oxigeno"])) / 2);
  const capa4 = Math.round((n(datos["capa4-hormonal"]) + n(datos["capa4-plasticidad"])) / 2);
  const indiceGlobal = n(datos["indice-global"]) ||
    Math.round((capa1 + capa2 + capa3 + capa4) / 4);

  return { capa1, capa2, capa3, capa4, indiceGlobal };
}

// ─── Estado por score ─────────────────────────────────────────
export function estadoPorScore(score: number): EstadoCapa {
  if (score < 30) return "CRÍTICO";
  if (score < 55) return "ALERTA";
  return "ÓPTIMO";
}

export function coloresPorEstado(estado: EstadoCapa) {
  const mapa = {
    "CRÍTICO": { color: "#D85A30", colorLight: "#FAECE7" },
    "ALERTA":  { color: "#BA7517", colorLight: "#FAEEDA" },
    "ÓPTIMO":  { color: "#1D9E75", colorLight: "#E1F5EE" },
  };
  return mapa[estado];
}

// ─── Interpretación completa del sistema ─────────────────────
export function interpretarSistema(
  scores: Scores,
  datos: DatosEvaluacion
): Interpretacion {

  const nombre = datos.nombre ?? "Cliente";
  const motivo = datos.motivo ?? "optimización del sistema";

  // ── Análisis por capa ────────────────────────────────────
  const capas: Record<number, InterpretacionCapa> = {
    1: buildCapa1(scores.capa1, motivo),
    2: buildCapa2(scores.capa2, scores.capa1),
    3: buildCapa3(scores.capa3, motivo),
    4: buildCapa4(scores.capa4),
  };

  // ── Capa de mayor compromiso ─────────────────────────────
  const scores_array = [
    { n: 1, v: scores.capa1 },
    { n: 2, v: scores.capa2 },
    { n: 3, v: scores.capa3 },
    { n: 4, v: scores.capa4 },
  ];
  const capaFalloObj = scores_array.reduce((a, b) => a.v < b.v ? a : b);
  const capaFallo = capaFalloObj.n;

  const nombreCapas: Record<number, string> = {
    1: "Entorno",
    2: "Regulación sistémica",
    3: "Metabolismo celular",
    4: "Expresión fenotípica",
  };

  // ── Tipo de atractor ─────────────────────────────────────
  const attractor = detectarAttractor(scores, motivo);

  // ── Cascada ──────────────────────────────────────────────
  const cascada = buildCascada(capaFallo, motivo);

  // ── Resumen ejecutivo personalizado ──────────────────────
  const resumenEjecutivo = buildResumen(nombre, capaFallo, nombreCapas, scores, motivo);

  // ── Protocolo personalizado ──────────────────────────────
  const protocolo = buildProtocolo(scores, capaFallo, motivo);

  // ── Próximos pasos ───────────────────────────────────────
  const proximosPasos: PasoItem[] = [
    {
      numero: "01",
      titulo: "Reserva tu sesión de Reconfiguración Sistémica (P02 · 247 €)",
      descripcion:
        "Este reporte es el punto de partida. La sesión inicial profundiza en tus variables específicas y diseña el protocolo completo de 2 meses con ajuste dinámico.",
    },
    {
      numero: "02",
      titulo: `Implementa las acciones de Capa ${capaFallo} desde hoy`,
      descripcion:
        "No es necesario esperar a la sesión. Las primeras acciones del protocolo pueden comenzar hoy mismo y ya generan cambio en el sistema.",
    },
    {
      numero: "03",
      titulo: "Monitorea tu energía durante 7 días",
      descripcion:
        "Anota del 0 al 10 tu nivel de energía al despertar y a las 15h cada día. Trae esos datos a la primera sesión.",
    },
  ];

  return {
    capas,
    capaFallo,
    nombreCapaFallo: nombreCapas[capaFallo],
    tipoAttractor: attractor,
    cascada,
    resumenEjecutivo,
    protocolo,
    proximosPasos,
  };
}

// ─── Helpers de construcción ──────────────────────────────────

function buildCapa1(score: number, motivo: string): InterpretacionCapa {
  const estado = estadoPorScore(score);
  const { color, colorLight } = coloresPorEstado(estado);
  return {
    estado, color, colorLight,
    titulo: "Entorno",
    variables: "pH · voltaje bioeléctrico · carga emocional · tóxicos",
    analisis: score < 30
      ? `Un pH ácido sostenido y una carga emocional elevada están desplazando tu atractor fisiológico hacia el modo de supervivencia. El entorno no proporciona las condiciones mínimas para que tu biología opere con plasticidad. Mientras el entorno permanezca en este rango, la probabilidad de cambio de estado tiende a cero. Esto explica directamente el patrón de ${motivo} que describes.`
      : score < 55
      ? `El entorno muestra señales de desequilibrio que condicionan las capas inferiores. El pH y la carga emocional están en rango de alerta. El sistema puede autorregularse, pero con coste energético elevado.`
      : `El entorno está dentro de parámetros que permiten la autorregulación. El pH y el estado bioeléctrico sostienen la coherencia biológica.`,
    accionClave: "Alcalinizar el entorno: dieta, grounding y reducción de carga emocional.",
  };
}

function buildCapa2(score: number, scoreCapa1: number): InterpretacionCapa {
  const estado = estadoPorScore(score);
  const { color, colorLight } = coloresPorEstado(estado);
  return {
    estado, color, colorLight,
    titulo: "Regulación sistémica",
    variables: "SNA · cortisol salival · microbiota · inflamación",
    analisis: score < 30
      ? `Tu sistema nervioso autónomo muestra un tono simpático crónicamente elevado${scoreCapa1 < 40 ? ", consecuencia directa del entorno comprometido" : ""}. El eje HPA produce cortisol de forma sostenida, cronificando la respuesta de alerta y dificultando la recuperación. El sistema interpreta el entorno como amenaza existencial de manera continua.`
      : score < 55
      ? `El SNA muestra un desequilibrio hacia el tono simpático que genera activación sostenida. El cortisol está en niveles que dificultan la regeneración nocturna y la plasticidad adaptativa.`
      : `La regulación sistémica muestra equilibrio entre el sistema nervioso simpático y parasimpático. El eje de estrés responde de forma adaptativa.`,
    accionClave: "Activar el nervio vago: respiración 4-7-8, frío y grounding.",
  };
}

function buildCapa3(score: number, motivo: string): InterpretacionCapa {
  const estado = estadoPorScore(score);
  const { color, colorLight } = coloresPorEstado(estado);
  const esFatiga = motivo.toLowerCase().includes("fatiga") ||
    motivo.toLowerCase().includes("energía") ||
    motivo.toLowerCase().includes("cansancio");
  return {
    estado, color, colorLight,
    titulo: "Metabolismo celular",
    variables: "ATP estimado · saturación O₂ · ORP / redox · temperatura basal",
    analisis: score < 30
      ? `La producción de ATP está seriamente comprometida.${esFatiga ? " Esto explica directamente el patrón de fatiga que describes:" : ""} tu sistema no genera suficiente energía celular para sostener las funciones normales. La disfunción mitocondrial hace que cada célula opere en modo de ahorro energético, priorizando la supervivencia sobre la función y la regeneración.`
      : score < 55
      ? `El metabolismo celular muestra una eficiencia reducida. La producción de ATP no alcanza los niveles óptimos, lo que genera una fatiga funcional que el sistema compensa con mecanismos de ahorro energético.`
      : `El metabolismo celular opera dentro del rango de eficiencia. La producción de ATP, la saturación de O₂ y el balance redox sostienen la función celular normal.`,
    accionClave: "Soporte mitocondrial: CoQ10, reducción de estrés oxidativo y oxigenación.",
  };
}

function buildCapa4(score: number): InterpretacionCapa {
  const estado = estadoPorScore(score);
  const { color, colorLight } = coloresPorEstado(estado);
  return {
    estado, color, colorLight,
    titulo: "Expresión fenotípica",
    variables: "hormonas · epigenética · atractor conductual · plasticidad",
    analisis: score < 30
      ? `Los desequilibrios hormonales y la reducida plasticidad fenotípica son consecuencia del estado de las capas anteriores. Cuando el sistema opera bajo estrés crónico con déficit energético, la expresión génica se adapta para priorizar la supervivencia sobre la regeneración. Este estado puede revertirse cuando se corrijan las capas de base.`
      : score < 55
      ? `La expresión fenotípica muestra adaptaciones al estado de las capas previas. Los marcadores hormonales y la plasticidad están condicionados por la carga del sistema operativo subyacente.`
      : `La expresión fenotípica está dentro del rango de plasticidad adaptativa. El sistema puede responder y ajustarse a los cambios del entorno.`,
    accionClave: "Restablecer base hormonal una vez corregidas las capas de entorno y energía.",
  };
}

function detectarAttractor(scores: Scores, motivo: string): string {
  const motiLC = motivo.toLowerCase();
  if (motiLC.includes("fatiga") || motiLC.includes("energía")) {
    return scores.capa3 < 30 ? "Atractor mitocondrial de supervivencia" : "Atractor de regulación energética";
  }
  if (motiLC.includes("hormonal") || motiLC.includes("ciclo") || motiLC.includes("sop")) {
    return "Atractor hormonal anclado en entorno";
  }
  if (motiLC.includes("ansiedad") || motiLC.includes("estrés") || motiLC.includes("nervios")) {
    return "Atractor nervioso-autónomo simpático";
  }
  if (motiLC.includes("inflamación") || motiLC.includes("autoinmune") || motiLC.includes("hashimoto")) {
    return "Atractor inflamatorio crónico";
  }
  return "Atractor de supervivencia metabólica por déficit de entorno";
}

function buildCascada(capaFallo: number, motivo: string): string {
  const cadenas: Record<number, string> = {
    1: `Capa 1 (Entorno) → Capa 2 (Regulación) → Capa 3 (Metabolismo) → ${motivo}`,
    2: `Capa 2 (Regulación) → Capa 3 (Metabolismo) → Capa 4 (Fenotipo) → ${motivo}`,
    3: `Capa 3 (Metabolismo) → Capa 4 (Fenotipo) → ${motivo}`,
    4: `Capa 4 (Fenotipo) → ${motivo}`,
  };
  return cadenas[capaFallo] ?? `Capa ${capaFallo} → ${motivo}`;
}

function buildResumen(
  nombre: string,
  capaFallo: number,
  nombreCapas: Record<number, string>,
  scores: Scores,
  motivo: string
): string {
  const idx = scores.indiceGlobal;
  const modo = idx < 30 ? "estado crítico de supervivencia" : idx < 55 ? "modo alerta sostenida" : "rango de alerta funcional";
  return (
    `${nombre}, tu sistema operativo biológico muestra un patrón claro: el punto de pérdida ` +
    `de autorregulación se localiza en la Capa ${capaFallo} — ${nombreCapas[capaFallo]}. ` +
    `Con un índice global de ${idx}/100, el sistema opera en ${modo}. ` +
    `Tu cuerpo no está fallando: está respondiendo de manera coherente a las condiciones ` +
    `en las que opera. El patrón de ${motivo} que describes es la solución que el sistema ` +
    `encontró para mantenerse estable. Cuando el entorno cambie, el sistema cambiará.`
  );
}

function buildProtocolo(
  scores: Scores,
  capaFallo: number,
  motivo: string
): ProtocoloItem[] {
  const motiLC = motivo.toLowerCase();
  const esFatiga = motiLC.includes("fatiga") || motiLC.includes("energía") || motiLC.includes("cansancio");

  const base: ProtocoloItem[] = [
    {
      tipo: "Nutrición",
      accion:
        "Dieta alcalinizante: eliminar azúcar refinado, lácteos convencionales y harinas blancas. " +
        "Base vegetal con énfasis en alimentos de alta densidad energética y minerales.",
      frecuencia: "Diario",
    },
    {
      tipo: "Bioelectricidad",
      accion:
        "Grounding 20 min/día sobre hierba o arena. " +
        "Baños de contraste progresivos (30 seg → 3 min agua fría). Restaura el voltaje de membrana celular.",
      frecuencia: "Diario",
    },
    {
      tipo: "Suplementación",
      accion: esFatiga
        ? "CoQ10 ubiquinol 200 mg · Magnesio glicinato 400 mg (noche) · Vitamina D3 5000 UI · B12 metilcobalamina 1000 mcg sublingual · NMN 500 mg."
        : "Magnesio glicinato 400 mg (noche) · Vitamina D3 5000 UI · Zinc picolinato 25 mg · Omega-3 2 g.",
      frecuencia: "Diario",
    },
    {
      tipo: "Hábitos",
      accion:
        "Exposición solar 20 min antes de las 10h. " +
        "Sin pantallas 1h antes de dormir. Caminata suave 30 min sin estímulos digitales.",
      frecuencia: "Diario",
    },
    {
      tipo: "Trabajo emocional",
      accion:
        "Diario de descarga emocional 10 min/noche. " +
        "Identificar y anotar el atractor emocional recurrente que sostiene la carga de Capa 1.",
      frecuencia: "Diario · 4 semanas",
    },
    {
      tipo: "Entorno",
      accion:
        "Mapear y reducir las 3 principales fuentes de activación simpática del entorno diario. " +
        "Reorganizar el contexto doméstico para minimizar el conflicto biológico activo.",
      frecuencia: "1x por semana",
    },
  ];

  // Si la capa 2 es la más comprometida, añadir protocolo nervioso
  if (capaFallo === 2 || scores.capa2 < 30) {
    base.splice(1, 0, {
      tipo: "Sistema nervioso",
      accion:
        "Respiración 4-7-8 al despertar y antes de dormir (3 ciclos mínimo). " +
        "Activa el nervio vago y reduce el tono simpático crónico.",
      frecuencia: "Diario · mañana y noche",
    });
  }

  return base;
}
