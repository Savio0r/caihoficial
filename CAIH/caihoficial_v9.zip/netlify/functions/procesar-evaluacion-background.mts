import type { Context } from "@netlify/functions";
import { generarReportePDF } from "./lib/generarReporte.js";
import { enviarEmailBienvenida } from "./lib/enviarEmail.js";
import { calcularScores, interpretarSistema } from "./lib/calcularScores.js";

// ─── Tipos ───────────────────────────────────────────────────
export interface DatosEvaluacion {
  nombre: string;
  email: string;
  motivo: string;
  "capa1-ph": string;
  "capa1-emocion": string;
  "capa2-sna": string;
  "capa2-cortisol": string;
  "capa3-atp": string;
  "capa3-oxigeno": string;
  "capa4-hormonal": string;
  "capa4-plasticidad": string;
  diagnostico: string;
  "indice-global": string;
  "capa-fallo": string;
}

// ─── Handler principal ────────────────────────────────────────
export default async (req: Request, context: Context) => {
  try {
    const payload = await req.json();

    // Netlify envía los datos en payload.data
    const datos: DatosEvaluacion = payload.data ?? payload;

    if (!datos.email || !datos.nombre) {
      console.error("Submission sin email o nombre:", payload);
      return;
    }

    console.log(`→ Procesando evaluación de ${datos.nombre} (${datos.email})`);

    // 1 · Calcular scores y generar interpretación
    const scores = calcularScores(datos);
    const interpretacion = interpretarSistema(scores, datos);

    console.log(`→ Scores calculados. Índice global: ${scores.indiceGlobal}`);

    // 2 · Generar PDF personalizado
    const pdfBuffer = await generarReportePDF(datos, scores, interpretacion);

    console.log(`→ PDF generado (${Math.round(pdfBuffer.length / 1024)} KB)`);

    // 3 · Enviar email con PDF adjunto
    await enviarEmailBienvenida(datos, scores, interpretacion, pdfBuffer);

    console.log(`✓ Email enviado a ${datos.email}`);

  } catch (err) {
    console.error("Error en pipeline CAIH:", err);
  }
};
